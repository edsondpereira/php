<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Alunos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <h1>CADASTRO DE ALUNOS</h1>
    <form name="cadaluno" method="post" action="">
        <p>
            <label>Nome do aluno:</label><br>
            <input type="text" name="aluno" required maxlength="60"><br>
        </p>
        <p>
            <label>E-mail:</label><br>
            <input type="email" name="email" required maxlength="30"><br>
        </p>
        <p>
            <label>Contato:</label><br>
            <input type="text" name="contato" maxlength="15">
        </p>
        <p>
            <button type="submit" name="inserir" class="btn btn-primary">Inserir</button>
        </p>
    </form>
    <?php
        if($_SERVER['REQUEST_METHOD'] =='POST')
        {
            require "conexao.php";
            $aluno  =   $_POST["aluno"];
            $email  =   $_POST["email"];
            $contato=   $_POST["contato"];

            // Inserindo os dados na tabela de aluno
            $sql="INSERT INTO tbaluno (nome, email, contato)";
            $sql.= " VALUES ('$aluno', '$email', '$contato')";
            mysqli_query($conexao, $sql) or die (mysqli_error($conexao));
            mysqli_close($conexao);
            echo "Aluno cadastrado com sucesso!";
        }

        // Pesquisando os dados cadastrados
        require "conexao.php";
        $sql="SELECT * FROM tbaluno ORDER BY nome";
        $resul = mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
        echo "<table class='table'>";
            echo "<tr>";
                echo "<th>Código</th>";
                echo "<th>Nome do aluno</th>";
                echo "<th>E-mail</th>";
                echo "<th>Contato</th>";
            echo "</tr>";

            while ($linha = mysqli_fetch_array($resul))
            {
                $codigo =   $linha["codigo"];
                $aluno  =   $linha["nome"];
                $email  =   $linha["email"];
                $contato=   $linha["contato"];

                // Exibindo os dados
                echo "<tr>";
                    echo "<td>$codigo</td>";
                    echo "<td>$aluno</td>";
                    echo "<td>$email</td>";
                    echo "<td>$contato</td>";
                echo "</tr>";
            }
        echo "</table>";
    ?>
</body>
</html>