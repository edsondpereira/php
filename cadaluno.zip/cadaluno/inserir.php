<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Alunos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="js/jquery.js"></script>
    <script src="js/jquery.mask.js"></script>
</head>

<body>
    <script>
        $(function(){
            $(".contato").mask("(00) 00000-0000", {placeholder: "(00) 00000-0000"});
            $(".cep").mask("00000-000", {placeholder: "00000-000"});
            $(".cpf").mask("000.000.000-00", {placeholder: "000.000.000-00"});
        })
    </script>
    <div class="container mt-4">
        <h1>Cadastro de Alunos</h1>

        <form name="cadaluno" method="post" action="">
            <div class="form-group">
                <label>Nome do aluno:</label><br>
                <input type="text" class="form-control" name="aluno" required maxlength="60"><br>
            </div>
            <div class="form-group">
                <label>E-mail:</label><br>
                <input type="email" class="form-control" name="email" required maxlength="30"><br>
            </div>
            <div class="form-group">
                <label>Contato:</label><br>
                <input type="text"  name="contato" class="contato" maxlength="15">
            </div>
            <div class="form-group mt-3">
                <button type="submit" name="inserir" class="btn btn-primary">Inserir</button>
                <a href="index.php" class="btn btn-secondary">Voltar</a>
            </div>
        </form>

        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            require "conexao.php";

            $aluno   = $_POST["aluno"];
            $email   = $_POST["email"];
            $contato = $_POST["contato"];
            $situacao = 'Ativo';

            // SQL com parâmetros
            $sql = "INSERT INTO tbaluno (nome, email, contato, situacao)
            VALUES (?, ?, ?, ?)";

            $stmt = mysqli_prepare($conexao, $sql);
            if ($stmt) {
                // ssss = 4 strings
                mysqli_stmt_bind_param($stmt, "ssss", $aluno, $email, $contato, $situacao);

                if (mysqli_stmt_execute($stmt)) {
                    echo "Aluno cadastrado com sucesso!";
                } else {
                    echo "Erro ao executar: " . mysqli_stmt_error($stmt);
                }

                mysqli_stmt_close($stmt);
            } else {
                echo "Erro na preparação: " . mysqli_error($conexao);
            }
            mysqli_close($conexao);
        }
        ?>
    </div>

</body>

</html>