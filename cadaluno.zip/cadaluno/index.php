<!DOCTYPE html>
<html lang="pt-br>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Alunos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-5">
        <h1>Cadastro de Alunos</h1>
        <a href="inserir.php" class="btn btn-success mx-5">Cadastrar aluno</a>
    </div>

        <?php
        
        require "conexao.php";
       
        // Ativos
        $sqlAtivos = "SELECT COUNT(*) AS total FROM tbaluno WHERE situacao = 'Ativo'";
        $resultAtivos = mysqli_query($conexao, $sqlAtivos);
        $rowAtivos = mysqli_fetch_assoc($resultAtivos);
        $totalAtivos = $rowAtivos['total'];

        // Inativos
        $sqlInativos = "SELECT COUNT(*) AS total FROM tbaluno WHERE situacao = 'Inativo'";
        $resultInativos = mysqli_query($conexao, $sqlInativos);
        $rowInativos = mysqli_fetch_assoc($resultInativos);
        $totalInativos = $rowInativos['total'];
    
        echo "<div style='display: flex; gap: 20px;'>";

        echo "<div class='card text-white' style='width: 18rem; background-color: blue;'>";
        //echo "<img class='card-img-top' src='...' alt='Card image cap'>";
        echo "<div class='card-body'>";
        echo "<h5 class='card-title'>Alunos Ativos</h5>";

        echo "<p class='card-text'>";
        echo "Total de alunos ativos: <strong>" . $totalAtivos . "</strong>";
        echo "</p>";

        //<a href="#" class="btn btn-primary">Ver alunos</a>
        echo "</div>";
        echo "</div>";

        echo "<div class='card text-white' style='width: 18rem; background-color: red;'>";
        //echo "<img class='card-img-top' src='...' alt='Card image cap'>";
        echo "<div class='card-body'>";
        echo "<h5 class='card-title'>Alunos Inativos</h5>";

        echo "<p class='card-text'>";
        echo "Total de alunos inativos: <strong>" . $totalInativos . "</strong>";
        echo "</p>";

        //<a href="#" class="btn btn-primary">Ver alunos</a>
        echo "</div>";
        echo "</div>";
        echo "</div>";
        // Pesquisando os dados cadastrados
        require "conexao.php";
        $sql="SELECT * FROM tbaluno ORDER BY nome";
        $resul = mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
        echo "<table class='table'>";
            echo "<tr>";
                echo "<th>Código</th>";
                echo "<th>Nome do aluno</th>";
                echo "<th>E-mail</th>";
                echo "<th>Contato</th>";
                echo "<th>Situação</th>";
                echo "<th>Editar</th>";
                echo "<th>Cancelar</th>";
            echo "</tr>";

            while ($linha = mysqli_fetch_array($resul))
            {
                $codigo     =   $linha["codigo"];
                $aluno      =   $linha["nome"];
                $email      =   $linha["email"];
                $contato    =   $linha["contato"];
                $situacao   =   $linha["situacao"];

                // Exibindo os dados
                echo "<tr>";
                    echo "<td>$codigo</td>";
                    echo "<td>$aluno</td>";
                    echo "<td>$email</td>";
                    echo "<td>$contato</td>";
                    echo "<td>$situacao</td>";
                    echo "<td><a href='editar.php?codigo=$codigo' class='btn btn-sm btn-warning'>Editar</a></td>";
                    echo "<td><a href='cancelar.php?codigo=$codigo' class='btn btn-sm btn-danger'>Cancelar</a></td>";
                echo "</tr>";
            }
        echo "</table>";
    ?>
</body>
</html>