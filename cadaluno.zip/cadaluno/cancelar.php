<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cancelar o cadastro de Alunos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h3 class="text-center text-primary">Cancelar Cadastro de Aluno</h3>
        <?php
        require "conexao.php";
        $codigo = $_REQUEST['codigo'];
        $sql = "SELECT * FROM tbaluno WHERE codigo = $codigo";
        $resultado = mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
        $linha = mysqli_fetch_array($resultado);
        $codigo = $linha['codigo'];
        $nome   = $linha['nome'];
        $email  = $linha['email'];
        $contato = $linha['contato'];
        $situacao = $linha['situacao'];

        echo "<form name='aluno' action='' method='POST'>";
        echo "<table border='1' align='center' cellpadding='4'>";
        echo "<tr>";
        echo "<th><label>Código:</label></th>";
        echo "<td><input type='text' name='codigo' size='5' maxlength='5' value='$codigo' readonly></td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th><label>Nome do aluno:</label></th>";
        echo "<td><input type='text' name='nome' size='60' maxlength='60' value='$nome' readonly></td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th><label>E-mail:</label></th>";
        echo "<td><input type='email' name='email' size='30' maxlength='35' value='$email' readonly></td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th><label>Contato:</label></th>";
        echo "<td><input type='text' name='contato' size='15' maxlength='15' value='$contato' readonly></td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th><label>Situação:</label></th>";
        echo "<td>";
        echo "<select name='situacao' required>";
        echo "<option>$situacao</option>";
        //echo "<option value='Ativo'>Ativo";
        //echo "<option value='Inativo'>Inativo";
        echo "</select>";
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td colspan='2' align='center'><input type='submit' value='Confirma' class='btn btn-primary mr-2'>";
        echo "&nbsp;&nbsp;<a href='index.php' class='btn btn-danger'>Voltar</a></td>";
        echo "</tr>";

        echo "</table>";
        echo "</form>";
        ?>

        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            require "conexao.php";
            $codigo =   $_POST["codigo"];
            $situacao = 'Inativo';
            $sql = "UPDATE tbaluno SET situacao = ? WHERE codigo = ?";
            $stmt = mysqli_prepare($conexao, $sql);

            if ($stmt) {
                // "sssi" = texto (nome), texto (email), texto (contato) e número inteiro (codigo)
                mysqli_stmt_bind_param($stmt, "si", $situacao, $codigo);

                if (mysqli_stmt_execute($stmt)) {
                    echo "<script>alert('Aluno cancelado com sucesso!');</script>";
                } else {
                    echo "Erro ao atualizar dados: " . mysqli_stmt_error($stmt);
                }

                mysqli_stmt_close($stmt);
            } else {
                echo "Erro na preparação da edição: " . mysqli_error($conexao);
            }

            // Fecha a conexão com o banco de dados
            mysqli_close($conexao);
            echo "<meta http-equiv='refresh' content='3;url=index.php' />";
        }
        ?>
    </div>
</body>

</html>