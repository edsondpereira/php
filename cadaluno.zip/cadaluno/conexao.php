<?php
$host   =   "localhost";
$user   =   "root";
$pass   =   "";
$banco  =   "bdaluno";
$conexao = mysqli_connect($host, $user, $pass) or die("Erro de conexão!");
mysqli_select_db($conexao, $banco) or die(mysqli_error($conexao));
mysqli_set_charset($conexao, "utf8");
?>